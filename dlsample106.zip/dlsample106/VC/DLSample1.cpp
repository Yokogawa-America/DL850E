// DL7400SampleDlg.cpp : �C���v�������e�[�V���� �t�@�C��
//
#include "stdafx.h"
#include "DLSample1.h"

int		StartFlag;									// Start Flag
int		Dev;										// Device ID
short	WaveBuffer[TEMP_DATA_LENGTH];				// WaveData Buffer(WORD)
char	WaveBufferB[TEMP_DATA_LENGTH];				// WaveData Buffer(BYTE)

int	InitDevice( int wire, char* address )
{
	int		timeout;								// Timeout
	int		sts;

	timeout = 300;									// Timeout = 30s
	
	if(wire == TM_CTL_USBTMC2){
		char usbtmc_adr[256];
		TmcEncodeSerialNumber(usbtmc_adr, sizeof(usbtmc_adr), address);
		address = usbtmc_adr;
	}
	
	sts = TmcInitialize( wire, address, &Dev );		// Initialize
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	sts = TmcSetTimeout( Dev, timeout );			// Timeout = 10s
	if( CTL_OK != sts ){
		DisplayError( Dev );
		CloseDevice();								// Device Clear
		return sts;
	}
	return sts;
}

void CloseDevice( void )
{
	TmcFinish( Dev );
	Dev = -1;
}

void DisplayError( int id )
{
	char	*ers;
	int		err;
	CString	errMes;

	err = TmcGetLastError( id );					// Get Error No.
	if( 2 == err )
		ers = "Device not found";
	else if( 4 == err )
		ers = "Connection to device failed";
	else if( 8 == err )
		ers = "Device not connected";
	else if( 16 == err )
		ers = "Device already connected";
	else if( 32 == err )
		ers = "Incompatible PC";
	else if( 64 == err )
		ers = "Illegal parameter";
	else if( 256 == err )
		ers = "Send error";
	else if( 512 == err )
		ers = "Receive error";
	else if( 1024 == err )
		ers = "Received data not block data";
	else if( 4096 == err )
		ers = "System error";
	else if( 8192 == err )
		ers = "Illegal device ID";
	else
		ers = "";
	errMes.Format( "Error No.%d \n \"%s\"", err, ers );
	AfxMessageBox( (LPCTSTR)errMes, MB_OK | MB_ICONEXCLAMATION, 0 );
}

int GetTdiv( char* ans )
{
	char	*msg;									// Command buffer
	int		sts;
	int		rlen;


	msg = "TIMEBASE:TDIV 2ms";						// Set T/div = 2ms
	sts = TmcSend( Dev, msg );						// Send Command
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "TIMEBASE:TDIV?";							// Get T/div value
	sts = TmcSend( Dev, msg );						// Send Command
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	sts = TmcReceive( Dev, ans, (int)TEMP_BUFF_SIZE, &rlen );
													// Receive Query
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	ans[ rlen-1 ] = '\0';
	return sts;
}

int GetWord( char lst[][TEMP_BUFF_SIZE], int* cnt )
{
	char		*msg;								// Command buffer
	char		qry[TEMP_BUFF_SIZE];				// Query buffer
	CString		dlm;								// DL MODEL Number
	int			sts;
	double		vdv;								// Vdiv value
	double		ofs;								// Offset value
	double		div;								// Division Value
	int			dlg;								// Block Data Length
	double		dat;								// Data
	int			i;
	int			rLen;
	int			endflag;

	msg = "*IDN?";									// DL MODEL Number
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	sts = TmcReceive( Dev, qry, TEMP_BUFF_SIZE, &rLen);
													// Receive Query
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	if(strncmp(&qry[9], "DL850", 5) == 0){
		div = 2400; // for DL850 Series
	}
	else{
		CString		dlm;								// DL MODEL Number
		dlm = qry;
		dlm = dlm.Mid( 9, 4);							// dlm = DL MODEL Number
		if( 0 == dlm.CompareNoCase( "7012" ) ){
			div = 2400;
		}
		else if( 0 == dlm.CompareNoCase( "7101" ) || 0 == strncmp(&qry[9], "DLM4038",7 ) || 0 == strncmp(&qry[9], "DLM4058",7 )){
			div = 3200;
		}
		else{
			div = 3072;
		}
	}

	msg = "STOP";									// Stop Acquisition
	sts = TmcSend( Dev, msg );
    if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
    
    msg = "COMMUNICATE:HEADER OFF";					// Query Header Off(for Get V/div)
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "WAVEFORM:TRACE 1";						// Trace = 1
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
    
	msg = "WAVEFORM:RECORD 0";						// Record number = 0
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

    msg = "WAVEFORM:FORMAT WORD";					// Data Format = WORD
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "WAVEFORM:BYTEORDER LSBFIRST";			// Data Byte order = LSB First(for Little Endian)
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

    msg = "WAVEFORM:START 0;END 1001";				// START 0,END 1001(Length = 1002)
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "WAVEFORM:RANGE?";						// Get V/div value
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	sts = TmcReceive( Dev, qry, TEMP_BUFF_SIZE, &rLen );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	vdv = atof( qry );

	msg = "WAVEFORM:OFFSET?";						// Get Offset value
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	sts = TmcReceive( Dev, qry, TEMP_BUFF_SIZE, &rLen );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	ofs = atof( qry );

	msg = "WAVEFORM:SEND?";							// Receive Waveform Data
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	sts = TmcReceiveBlockHeader( Dev, &dlg );		// Receive Block Header
	if( CTL_OK != sts ){							// dlg = Data Byte Length
		DisplayError( Dev );
		return sts;
	}
	sts = TmcReceiveBlockData( Dev, (char*)WaveBuffer, dlg + 1, &rLen, &endflag );
													// Receive Waveform Data + LF
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	for( i=0; i < ( dlg / 2 ); i++ ){
		dat = WaveBuffer[i] * vdv / div + ofs;
		sprintf( lst[i], "%d:%f", i, dat );
	}
	*cnt = i;

	msg = "COMMUNICATE:HEADER ON";					// Query Header On
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	return sts;
}

int GetByte( char lst[][TEMP_BUFF_SIZE], int* cnt )
{
	char		*msg;								// Command buffer
	char		qry[TEMP_BUFF_SIZE];				// Query buffer
	int			sts;
	double		vdv;								// Vdiv value
	double		ofs;								// Offset value
	double		div;								// Division Value
	int			dlg;								// Block Data Length
	double		dat;								// Data
	int			i;
	int			rLen;
	int			endflag;

	msg = "*IDN?";									// DL MODEL Number
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	sts = TmcReceive( Dev, qry, TEMP_BUFF_SIZE, &rLen);
													// Receive Query
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	
	if(strncmp(&qry[9], "DL850", 5) == 0){
		div = 9.375; // for DL850 Series
	}
	else{
		CString		dlm;								// DL MODEL Number
		dlm = qry;
		dlm = dlm.Mid( 9, 4);							// dlm = DL MODEL Number
		if( 0 == dlm.CompareNoCase( "7012" ) ){
			div = 9.375;
		}
		else if( 0 == dlm.CompareNoCase( "7101" ) || 0 == strncmp(&qry[9], "DLM4038", 7) || 0 == strncmp(&qry[9], "DLM4058", 7)){
			div = 12.5;
		}
		else{
			div = 12;
		}
	}

	msg = "STOP";									// Stop Acquisition
	sts = TmcSend( Dev, msg );
    if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
    
    msg = "COMMUNICATE:HEADER OFF";					// Query Header Off(for Get V/div)
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "WAVEFORM:TRACE 1";						// Trace = 1
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
    
	msg = "WAVEFORM:RECORD 0";						// Record number = 0
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

    msg = "WAVEFORM:FORMAT BYTE";					// Data Format = BYTE
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

    msg = "WAVEFORM:START 0;END 1001";				// START 0,END 1001(Length = 1002)
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "WAVEFORM:RANGE?";						// Get V/div value
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	sts = TmcReceive( Dev, qry, TEMP_BUFF_SIZE, &rLen );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	vdv = atof( qry );

	msg = "WAVEFORM:OFFSET?";						// Get Offset value
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	sts = TmcReceive( Dev, qry, TEMP_BUFF_SIZE, &rLen );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	ofs = atof( qry );

	msg = "WAVEFORM:SEND?";							// Receive Waveform Data
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	sts = TmcReceiveBlockHeader( Dev, &dlg );		// Receive Block Header
	if( CTL_OK != sts ){							// dlg = Data Byte Length
		DisplayError( Dev );
		return sts;
	}
	sts = TmcReceiveBlockData( Dev, (char*)WaveBufferB, dlg + 1, &rLen, &endflag );
													// Receive Waveform Data + LF
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	for( i=0; i < dlg; i++ ){
		dat = WaveBufferB[i] * vdv / div + ofs;
		sprintf( lst[i], "%d:%f", i, dat );
	}
	*cnt = i;

	msg = "COMMUNICATE:HEADER ON";					// Query Header On
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	return sts;
}

int GetMeasure( char lst[][TEMP_BUFF_SIZE] )
{
	char		*msg;								// Command buffer
	char		qry[TEMP_BUFF_SIZE];				// Query buffer
	int			sts;
	int			stp;
	int			rLen;

	msg = "STOP";									// Acquisition = Stop
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "COMMUNICATE:HEADER OFF";					// Query Header Off(for Get V/div)
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "MEASURE:MODE OFF";						// Measure Off
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "CHANNEL1:DISPLAY ON";					// CH1 On
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
    
	msg = "CHANNEL1:PROBE 10";						// CH1 Probe = 10:1
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "CHANNEL1:VDIV 500mV";					// CH1 V/div = 500mV
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "ACQUIRE:MODE NORMAL;RLENGTH 1000000";	// Acquisition mode = NORMAL, length = 1000000
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "TIMEBASE:TDIV 100ms";					// T/div = 100ms
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "TRIGGER:SIMPLE:LEVEL 500mV";				// Trigger level = 500mV
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = ":TRIGGER:TYPE SIMPLE;";					// Trigger Type = SIMPLE
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = ":TRIGGER:SIMPLE:SOURCE 1";				// Trigger Source = CH1
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "MEASURE:CHANNEL1:PTOPEAK:STATE ON";		// Measure P-P On
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "MEASURE:CHANNEL1:AVERAGE:STATE ON";		// Measure Average On
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "MEASURE:CHANNEL1:FREQUENCY:STATE ON";	// Measure Frequency On
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
    
	msg = "MEASURE:TRANGE -5,5";					// Measure Time Range -5,5
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "SSTART? 500";							// Start Single Trigger
	sts = TmcSend( Dev, msg );						// Wait until stop Acquisition
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	sts = TmcReceive( Dev, qry, TEMP_BUFF_SIZE, &rLen );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	stp = atoi( qry );
	if( 1 == stp ){
		return MEAS_NOT_TRIG;						// Not TRIG'D
	}

    msg = "MEASURE:MODE ON";						// Start Measure
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "MEASURE:WAIT? 100";						// Wait until stop Measure
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	sts = TmcReceive( Dev, qry, TEMP_BUFF_SIZE, &rLen );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	stp = atoi( qry );
	if( 1 == stp ){
		return MEAS_NOT_FIN;						// Measure not finish
	}

	msg = "MEASURE:CHANNEL1:PTOPEAK:VALUE?";		// Get P-P value
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
 	sts = TmcReceive( Dev, qry, TEMP_BUFF_SIZE, &rLen );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	qry[ rLen-1 ] = '\0';
	sprintf( lst[0], "Peak To Peak:%s", qry );

	msg = "MEASURE:CHANNEL1:AVERAGE:VALUE?";		// Get Average value
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
 	sts = TmcReceive( Dev, qry, TEMP_BUFF_SIZE, &rLen );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	qry[ rLen-1 ] = '\0';
	sprintf( lst[1], "Average:%s", qry );

	msg = "MEASURE:CHANNEL1:FREQUENCY:VALUE?";		// Get Freq value
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
 	sts = TmcReceive( Dev, qry, TEMP_BUFF_SIZE, &rLen );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	qry[ rLen-1 ] = '\0';
	sprintf( lst[2], "Frequency:%s", qry );

    msg = "COMMUNICATE:HEADER ON";					// Query Header On
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	return sts;
}

int SaveFile( char* ans )
{
	char		*msg;								// Command buffer
	char		qry[TEMP_BUFF_SIZE];				// Query buffer
	int			sts;
	int			rlen;
	int			cond;

	
	msg = "INITIALIZE:EXECUTE";						// Execute Initialize
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "CALIBRATE:EXECUTE";						// Execute Calibrate
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "ASETUP:EXECUTE";							// Execute AutoSetup
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	do{												// When Start -> COND And 1 -> 1
		Sleep( 100 );								// Wait 100ms
		msg = "STATUS:CONDITION?";					// Read Condition Register
		sts = TmcSend( Dev, msg );					// Send Command
		if( CTL_OK != sts ){
			DisplayError( Dev );					// SaveFile = 1
			return sts;
		}
		sts = TmcReceive( Dev, qry, TEMP_BUFF_SIZE, &rlen );
													// Receive Query
		if( CTL_OK != sts ){
			DisplayError( Dev );
			return sts;
		}
		cond = atoi( qry );
	}while( 0 == (1 & cond) );

	Sleep( 2000 );									// Wait 2s   

	msg = "STOP";									// Stop
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "COMMUNICATE:OVERLAP 64";					// Enable Access Overlap
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "*CLS";									// Clear Error Status
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

    msg = "*IDN?";									// DL MODEL Number
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	sts = TmcReceive( Dev, qry, TEMP_BUFF_SIZE, &rlen );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	
	if(strncmp(&qry[9], "DL850", 5) == 0){
		msg = "FILE:SAVE:ANAMING NUMB;NAME \"TEST\""; // for DL850 Series
	}
	else{
		CString		dlm;								// DL MODEL Number
		dlm = qry;
		dlm = dlm.Mid( 9, 6);							// dlm = DL MODEL Number
  		if( 0 == dlm.CompareNoCase( "701210" ) ){
			msg = "FILE:SAVE:ANAMING NUMB;NAME \"TEST\"";
														// Save File Name = "TESTXXXX"
		}
		else{
			msg = "FILE:SAVE:ANAMING ON;NAME \"TEST\"";	// Save File Name = "TESTXXXX"
		}
	}
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

    msg = "FILE:SAVE:BINARY:EXECUTE";				// Execute File Save
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	do{												// When Save Finish -> COND->0
		Sleep( 100 );								// Wait 100ms
		msg = "STATUS:COND?";						// Read EESR Register
		sts = TmcSend( Dev, msg );
		if( CTL_OK != sts ){
			DisplayError( Dev );
			return sts;
		}
		sts = TmcReceive( Dev, qry, TEMP_BUFF_SIZE, &rlen );
		if( CTL_OK != sts ){
			DisplayError( Dev );
			return sts;
		}
		cond = atoi( qry );
	}while( 64 == cond );

	msg = "STATUS:ERROR?";							// Read Status Error
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	sts = TmcReceive( Dev, ans, TEMP_BUFF_SIZE, &rlen );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	ans[ rlen-1 ] = '\0';

	msg = "COMMUNICATE:OVERLAP 0";					// Disable Access Overlap
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	return sts;
}

int PresetToGetWordRuntime( void )
{
	char		msg[TEMP_BUFF_SIZE];
	int			sts, i;
	int			rlen;
	int			cnt;

	strcpy( msg, "INITIALIZE:EXECUTE" );			// Initialize
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	strcpy( msg, "ACQUIRE:RLENGTH 1250" );			// Set RecordLength = 1.25kpoints
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	strcpy(msg, "*IDN?" );									// DL MODEL Number
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	sts = TmcReceive( Dev, msg, (int)TEMP_BUFF_SIZE, &rlen);
													// Receive Query
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	if((strncmp(&msg[9],"DLM4038",7) == 0) || (strncmp(&msg[9],"DLM4058",7) == 0)){
		cnt = 8;
	}else if((strncmp(&msg[9],"710110",6) == 0) || (strncmp(&msg[9],"710120",6) == 0) || (strncmp(&msg[9],"710130",6) == 0)){
		cnt = 4;
	}else{
		cnt = 2;
	}
	
	for( i=0; i<cnt; i++){
		sprintf( msg, "CHAN%d:PROBE 10", i+1 );		// Set CH Probe = 10:1
		sts = TmcSend( Dev, msg );
		if( CTL_OK != sts ){
			DisplayError( Dev );
			return sts;
		}

		sprintf( msg, "CHAN%d:VDIV 500mV", i+1 );	// Set CH V/Div = 500mV
		sts = TmcSend( Dev, msg );
		if( CTL_OK != sts ){
			DisplayError( Dev );
			return sts;
		}
	}

	strcpy( msg, "TIMEBASE:TDIV 500us" );			// Set T/div = 500us
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	strcpy( msg, "TRIGGER:SIMPLE:LEVEL 500mV" );		// Set Trigger Level = 500mV
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	strcpy( msg, "WAVEFORM:ALL:TRACE ALL" );		// Set Trace = ALL
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	return CTL_OK;
}
int CheckDLM2000_DLM4000( void )
{
	char		msg[TEMP_BUFF_SIZE];
	int			rlen;
	int			sts;
	char*		msgP;
	char*		modelP;

	strcpy( msg, "*IDN?" );								// Get Identification
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
														// Receive Query
	sts = TmcReceive( Dev, msg, (int)TEMP_BUFF_SIZE, &rlen );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	msg[ rlen-1 ] = '\0';

	msgP=msg;
	while(*msgP){										// Search first comma
		if(','==*msgP)
			break;
		msgP++;
	}

	if('\0'==*msgP)
		return CTL_ERROR;

	msgP++;
	modelP=msgP;

	while(*msgP){										// Search second comma
		if(','==*msgP)
			break;
		msgP++;
	}

	if('\0'==*msgP)
		return CTL_ERROR;

	*msgP='\0';											// Terminate model string
	
	if( 0 != strcmp( "710105", modelP )
		&& 0 != strcmp( "710110", modelP )
		&& 0 != strcmp( "710115", modelP )
		&& 0 != strcmp( "710120", modelP )
		&& 0 != strcmp( "710125", modelP )
		&& 0 != strcmp( "710130", modelP )
		&& 0 != strcmp( "DLM4038", modelP )
		&& 0 != strcmp( "DLM4058", modelP )){
		return CTL_ERROR;
	}

	return CTL_OK;
}
int GetWordRuntime( char lst[][TEMP_BUFF_SIZE], int* cnt )
{
	char		msg[TEMP_BUFF_SIZE];
	unsigned	char	header[RUNTIME_HEADER_SIZE];
	int			sts;
	int			dlg;									// Block Data Length
	int			i;
	int			rLen;
	int			lfLen;
	int			endflag;
	int			traceNum;
	static		__int64 acqCount=0;
	int			dataLen;
	float		vReso;									// V/LSB 

	sprintf( msg, ":WAVEFORM:ALL:SEND? %d", acqCount );	// Receive Waveform Data while Runtime
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	sts = TmcReceiveBlockHeader( Dev, &dlg );			// Receive Block Header
	if( CTL_OK != sts ){								// dlg = Data Byte Length
		DisplayError( Dev );
		return sts;
	}
	if(( 0 == dlg )||( TEMP_DATA_LENGTH < dlg))
		return CTL_OK;
														// Receive Runtime Common Header
	sts = TmcReceiveBlockData( Dev, (char*)header, RUNTIME_COMMON_HEADER_SIZE, &rLen, &endflag );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	traceNum = header[0] + ( header[1] << 8 );			// Get Trace Number
														// Get ACQ Count
	acqCount = header[2] + ( header[3] << 8 ) + ( header[4] << 16 ) + ( header[5] << 24 )
				+ ( header[6] << 32 ) + ( header[7] << 40 ) + ( header[8] << 48 ) + ( header[9] << 56 );

	for( i=0; i < traceNum; i++ ){					
														// Receive Runtime Trace Header
		sts = TmcReceiveBlockData( Dev, (char*)header, RUNTIME_TRACE_HEADER_SIZE, &rLen, &endflag );
		if( CTL_OK != sts ){
			DisplayError( Dev );
			return sts;
		}											
														// Get Data Length
		dataLen = header[12] + ( header[13] << 8 ) + ( header[14] << 16 ) + ( header[15] << 24 );

		if( traceNum - 1 == i )							// for LF
			lfLen=1;
		else
			lfLen=0;

		sts = TmcReceiveBlockData( Dev, (char*)( WaveBuffer + dataLen * i ), dataLen * 2 + lfLen, &rLen, &endflag );
		if( CTL_OK != sts ){
			DisplayError( Dev );
			return sts;
		}
	}

	vReso=(float)0.5/3200;								// 500mV fix

	if(traceNum == 8)
		strcpy( lst[0], "No.,CH1(V),CH2(V),CH3(V),CH4(V),CH5(V),CH6(V),CH7(V),CH8(V)" );
	else if(traceNum == 4)
		strcpy( lst[0], "No.,CH1(V),CH2(V),CH3(V),CH4(V)" );
	else
		strcpy( lst[0], "No.,CH1(V),CH2(V)" );

	for( i = 0; i < dataLen; i++ ){
		if(traceNum == 8){
			sprintf( lst[ i+1 ], "%d,%3.2f,%3.2f,%3.2f,%3.2f,%3.2f,%3.2f,%3.2f,%3.2f"
				, i, WaveBuffer[ i ] * vReso, WaveBuffer[i + dataLen ] * vReso
				, WaveBuffer[i + dataLen * 2 ] * vReso, WaveBuffer[i + dataLen * 3 ] * vReso
				, WaveBuffer[i + dataLen * 4 ] * vReso, WaveBuffer[i + dataLen * 5 ] * vReso
				, WaveBuffer[i + dataLen * 6 ] * vReso, WaveBuffer[i + dataLen * 7 ] * vReso );
		}else if(traceNum == 4){
			sprintf( lst[ i+1 ], "%d,%3.2f,%3.2f,%3.2f,%3.2f"
				, i, WaveBuffer[ i ] * vReso, WaveBuffer[i + dataLen ] * vReso
				, WaveBuffer[i + dataLen * 2 ] * vReso, WaveBuffer[i + dataLen * 3 ] * vReso );
		}else{
			sprintf( lst[ i+1 ], "%d,%3.2f,%3.2f", i, WaveBuffer[ i ] * vReso, WaveBuffer[i + dataLen ] * vReso );
		}
	}

	*cnt = i + 1;

	return CTL_OK;
}